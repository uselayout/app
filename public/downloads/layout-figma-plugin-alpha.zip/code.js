"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // src/extraction/tokens.ts
  function extractTokensFromPage() {
    return __async(this, null, function* () {
      const colors = extractColorTokens();
      const typography = extractTypographyTokens();
      const effects = extractEffectTokens();
      const spacing = extractSpacingTokens();
      const radius = extractRadiusTokens();
      return { colors, typography, spacing, radius, effects };
    });
  }
  function extractColorTokens() {
    var _a;
    const paintStyles = figma.getLocalPaintStyles();
    const tokens = [];
    for (const style of paintStyles) {
      const paints = style.paints.filter(
        (p) => p.type === "SOLID" && p.visible !== false
      );
      if (paints.length === 0) continue;
      const paint = paints[0];
      const hex = rgbToHex(paint.color);
      const alpha = (_a = paint.opacity) != null ? _a : 1;
      const value = alpha < 1 ? rgbaToString(paint.color, alpha) : hex;
      tokens.push({
        name: style.name,
        value,
        cssVariable: nameToVariable(style.name),
        category: "color"
      });
    }
    return tokens;
  }
  function extractTypographyTokens() {
    const textStyles = figma.getLocalTextStyles();
    const tokens = [];
    for (const style of textStyles) {
      const fontSize = style.fontSize;
      const fontFamily = style.fontName.family;
      const fontWeight = fontWeightFromStyle(style.fontName.style);
      const lineHeight = formatLineHeight(style.lineHeight);
      const letterSpacing = formatLetterSpacing(style.letterSpacing);
      const parts = [`${fontSize}px`, fontFamily, `weight ${fontWeight}`];
      if (lineHeight) parts.push(`line-height ${lineHeight}`);
      if (letterSpacing) parts.push(`letter-spacing ${letterSpacing}`);
      tokens.push({
        name: style.name,
        value: parts.join(", "),
        cssVariable: nameToVariable(style.name),
        category: "typography"
      });
    }
    return tokens;
  }
  function extractEffectTokens() {
    const effectStyles = figma.getLocalEffectStyles();
    const tokens = [];
    for (const style of effectStyles) {
      const effects = style.effects.filter((e) => e.visible !== false);
      if (effects.length === 0) continue;
      const descriptions = effects.map((e) => {
        switch (e.type) {
          case "DROP_SHADOW":
          case "INNER_SHADOW": {
            const shadow = e;
            const color = rgbaToString(shadow.color, shadow.color.a);
            return `${e.type === "INNER_SHADOW" ? "inset " : ""}${shadow.offset.x}px ${shadow.offset.y}px ${shadow.radius}px ${color}`;
          }
          case "LAYER_BLUR":
            return `blur(${e.radius}px)`;
          case "BACKGROUND_BLUR":
            return `backdrop-blur(${e.radius}px)`;
          default:
            return e.type;
        }
      });
      tokens.push({
        name: style.name,
        value: descriptions.join(", "),
        cssVariable: nameToVariable(style.name),
        category: "effect"
      });
    }
    return tokens;
  }
  function extractSpacingTokens() {
    const tokens = [];
    const seen = /* @__PURE__ */ new Set();
    for (const node of figma.currentPage.children) {
      collectSpacing(node, seen, tokens, 0);
    }
    tokens.sort((a, b) => parseFloat(a.value) - parseFloat(b.value));
    return tokens;
  }
  function collectSpacing(node, seen, tokens, depth) {
    if (depth > MAX_DEPTH) return;
    if (!("layoutMode" in node)) return;
    const frame = node;
    if (frame.layoutMode !== "NONE") {
      const values = [
        frame.itemSpacing,
        frame.paddingTop,
        frame.paddingRight,
        frame.paddingBottom,
        frame.paddingLeft
      ];
      for (const v of values) {
        if (v > 0 && !seen.has(v)) {
          seen.add(v);
          tokens.push({
            name: `spacing-${v}`,
            value: `${v}px`,
            cssVariable: `--spacing-${v}`,
            category: "spacing"
          });
        }
      }
    }
    if ("children" in node) {
      for (const child of node.children) {
        collectSpacing(child, seen, tokens, depth + 1);
      }
    }
  }
  function extractRadiusTokens() {
    const tokens = [];
    const seen = /* @__PURE__ */ new Set();
    for (const node of figma.currentPage.children) {
      collectRadius(node, seen, tokens, 0);
    }
    tokens.sort((a, b) => parseFloat(a.value) - parseFloat(b.value));
    return tokens;
  }
  function collectRadius(node, seen, tokens, depth) {
    if (depth > MAX_DEPTH) return;
    if ("cornerRadius" in node && typeof node.cornerRadius === "number") {
      const r = node.cornerRadius;
      if (r > 0 && !seen.has(r)) {
        seen.add(r);
        tokens.push({
          name: `radius-${r}`,
          value: `${r}px`,
          cssVariable: `--radius-${r}`,
          category: "radius"
        });
      }
    }
    if ("children" in node) {
      for (const child of node.children) {
        collectRadius(child, seen, tokens, depth + 1);
      }
    }
  }
  function nameToVariable(name) {
    return `--${name.toLowerCase().replace(/\//g, "-").replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")}`;
  }
  function rgbToHex(color) {
    const r = Math.round(color.r * 255);
    const g = Math.round(color.g * 255);
    const b = Math.round(color.b * 255);
    return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
  }
  function rgbaToString(color, alpha) {
    const r = Math.round(color.r * 255);
    const g = Math.round(color.g * 255);
    const b = Math.round(color.b * 255);
    return `rgba(${r}, ${g}, ${b}, ${alpha.toFixed(2)})`;
  }
  function fontWeightFromStyle(style) {
    var _a;
    const map = {
      Thin: 100,
      ExtraLight: 200,
      Light: 300,
      Regular: 400,
      Medium: 500,
      SemiBold: 600,
      Bold: 700,
      ExtraBold: 800,
      Black: 900
    };
    return (_a = map[style.replace(/\s/g, "")]) != null ? _a : 400;
  }
  function formatLineHeight(lh) {
    if (!("unit" in lh)) return null;
    if (lh.unit === "AUTO") return null;
    if (lh.unit === "PERCENT") return `${lh.value}%`;
    return `${lh.value}px`;
  }
  function formatLetterSpacing(ls) {
    if (!("unit" in ls)) return null;
    if (ls.unit === "PERCENT") return `${ls.value}%`;
    if (ls.value === 0) return null;
    return `${ls.value}px`;
  }
  var MAX_DEPTH;
  var init_tokens = __esm({
    "src/extraction/tokens.ts"() {
      "use strict";
      MAX_DEPTH = 4;
    }
  });

  // src/extraction/components.ts
  function extractComponents() {
    return __async(this, null, function* () {
      var _a;
      const components = [];
      const seen = /* @__PURE__ */ new Set();
      const allNodes = [];
      for (const page of figma.root.children) {
        const found = page.findAll(
          (n) => n.type === "COMPONENT" || n.type === "COMPONENT_SET"
        );
        allNodes.push(...found);
        if (allNodes.length > MAX_COMPONENTS * 2) break;
      }
      for (const node of allNodes) {
        if (node.type === "COMPONENT_SET") {
          const componentSet = node;
          if (seen.has(componentSet.name)) continue;
          seen.add(componentSet.name);
          const variantCount = componentSet.children.length;
          const props = extractPropsFromSet(componentSet);
          components.push({
            name: componentSet.name,
            description: componentSet.description || void 0,
            variants: variantCount,
            props
          });
        } else if (node.type === "COMPONENT") {
          const component = node;
          if (((_a = component.parent) == null ? void 0 : _a.type) === "COMPONENT_SET") continue;
          if (seen.has(component.name)) continue;
          seen.add(component.name);
          components.push({
            name: component.name,
            description: component.description || void 0,
            variants: 1,
            props: extractPropsFromComponent(component)
          });
        }
        if (components.length >= MAX_COMPONENTS) break;
      }
      return components;
    });
  }
  function extractPropsFromSet(set) {
    const propNames = /* @__PURE__ */ new Set();
    for (const child of set.children) {
      if (child.type !== "COMPONENT") continue;
      const parts = child.name.split(",").map((p) => p.trim());
      for (const part of parts) {
        const eqIndex = part.indexOf("=");
        if (eqIndex > 0) {
          propNames.add(part.slice(0, eqIndex).trim());
        }
      }
    }
    return Array.from(propNames);
  }
  function extractPropsFromComponent(component) {
    try {
      const properties = component.componentPropertyDefinitions;
      if (!properties) return [];
      return Object.keys(properties);
    } catch (e) {
      return [];
    }
  }
  var MAX_COMPONENTS;
  var init_components = __esm({
    "src/extraction/components.ts"() {
      "use strict";
      MAX_COMPONENTS = 200;
    }
  });

  // src/extraction/screenshots.ts
  function captureScreenshot(node) {
    return __async(this, null, function* () {
      const bytes = yield node.exportAsync({
        format: "PNG",
        constraint: { type: "SCALE", value: 2 }
      });
      const base64 = uint8ToBase64(bytes);
      return `data:image/png;base64,${base64}`;
    });
  }
  function uint8ToBase64(bytes) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let result = "";
    const len = bytes.length;
    for (let i = 0; i < len; i += 3) {
      const b0 = bytes[i];
      const b1 = i + 1 < len ? bytes[i + 1] : 0;
      const b2 = i + 2 < len ? bytes[i + 2] : 0;
      result += chars[b0 >> 2];
      result += chars[(b0 & 3) << 4 | b1 >> 4];
      result += i + 1 < len ? chars[(b1 & 15) << 2 | b2 >> 6] : "=";
      result += i + 2 < len ? chars[b2 & 63] : "=";
    }
    return result;
  }
  var init_screenshots = __esm({
    "src/extraction/screenshots.ts"() {
      "use strict";
    }
  });

  // src/api/auth.ts
  function saveApiKey(apiKey) {
    return __async(this, null, function* () {
      yield figma.clientStorage.setAsync(STORAGE_KEY, apiKey);
    });
  }
  function getApiKey() {
    return __async(this, null, function* () {
      const key = yield figma.clientStorage.getAsync(STORAGE_KEY);
      return typeof key === "string" && key.length > 0 ? key : null;
    });
  }
  function clearApiKey() {
    return __async(this, null, function* () {
      yield figma.clientStorage.deleteAsync(STORAGE_KEY);
    });
  }
  function saveBaseUrl(url) {
    return __async(this, null, function* () {
      yield figma.clientStorage.setAsync(BASE_URL_KEY, url);
    });
  }
  function getBaseUrl() {
    return __async(this, null, function* () {
      const url = yield figma.clientStorage.getAsync(BASE_URL_KEY);
      return typeof url === "string" && url.length > 0 ? url : DEFAULT_BASE_URL;
    });
  }
  var STORAGE_KEY, BASE_URL_KEY, DEFAULT_BASE_URL;
  var init_auth = __esm({
    "src/api/auth.ts"() {
      "use strict";
      STORAGE_KEY = "layout-api-key";
      BASE_URL_KEY = "layout-base-url";
      DEFAULT_BASE_URL = "https://layout.design";
    }
  });

  // src/lib/figma-variables.ts
  function readLayoutVariables() {
    var _a;
    const collections = figma.variables.getLocalVariableCollections();
    const collection = collections.find((c) => c.name === COLLECTION_NAME);
    if (!collection) return [];
    const modeId = (_a = collection.modes[0]) == null ? void 0 : _a.modeId;
    if (!modeId) return [];
    return collection.variableIds.map((id) => figma.variables.getVariableById(id)).filter((v) => v !== null).map((v) => ({
      name: stripGroupPrefix(v.name),
      value: resolveValue(v, modeId),
      cssVariable: null
    }));
  }
  function stripGroupPrefix(name) {
    const slashIndex = name.indexOf("/");
    return slashIndex >= 0 ? name.slice(slashIndex + 1) : name;
  }
  function resolveValue(variable, modeId) {
    var _a;
    const raw = variable.valuesByMode[modeId];
    if (raw === void 0 || raw === null) return "";
    if (variable.resolvedType === "COLOR") {
      const c = raw;
      const r = Math.round(c.r * 255);
      const g = Math.round(c.g * 255);
      const b = Math.round(c.b * 255);
      const a = (_a = c.a) != null ? _a : 1;
      return a < 1 ? `rgba(${r},${g},${b},${a.toFixed(2)})` : `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
    }
    return String(raw);
  }
  function getOrCreateCollection() {
    const existing = figma.variables.getLocalVariableCollections().find((c) => c.name === COLLECTION_NAME);
    if (existing) return existing;
    const collection = figma.variables.createVariableCollection(COLLECTION_NAME);
    collection.renameMode(collection.modes[0].modeId, MODE_NAME);
    return collection;
  }
  function writeLayoutVariables(tokensByCategory) {
    const collection = getOrCreateCollection();
    const modeId = collection.modes[0].modeId;
    const errors = [];
    let written = 0;
    const existing = /* @__PURE__ */ new Map();
    for (const id of collection.variableIds) {
      const v = figma.variables.getVariableById(id);
      if (v) existing.set(v.name, v);
    }
    for (const [category, tokens] of Object.entries(tokensByCategory)) {
      for (const token of tokens) {
        try {
          const groupedName = `${category}/${token.name}`;
          const resolvedType = inferType(token.value);
          let variable = existing.get(groupedName);
          if (!variable) {
            const oldVariable = existing.get(token.name);
            if (oldVariable) {
              oldVariable.remove();
              existing.delete(token.name);
            }
          }
          if (!variable) {
            variable = figma.variables.createVariable(groupedName, collection, resolvedType);
          }
          const value = parseValue(token.value, resolvedType);
          variable.setValueForMode(modeId, value);
          written++;
        } catch (err) {
          errors.push(
            `${token.name}: ${err instanceof Error ? err.message : String(err)}`
          );
        }
      }
    }
    return { written, errors };
  }
  function deleteLayoutVariables(names) {
    const collections = figma.variables.getLocalVariableCollections();
    const collection = collections.find((c) => c.name === COLLECTION_NAME);
    if (!collection) return;
    const nameSet = new Set(names);
    for (const id of [...collection.variableIds]) {
      const v = figma.variables.getVariableById(id);
      if (!v) continue;
      const stripped = stripGroupPrefix(v.name);
      if (nameSet.has(stripped) || nameSet.has(v.name)) {
        v.remove();
      }
    }
  }
  function inferType(value) {
    const trimmed = value.trim();
    if (trimmed.startsWith("#") || trimmed.startsWith("rgb")) return "COLOR";
    const num = parseFloat(trimmed);
    if (!isNaN(num)) return "FLOAT";
    return "STRING";
  }
  function parseValue(value, type) {
    if (type === "COLOR") return hexToRgba(value);
    if (type === "FLOAT") return parseFloat(value);
    return value;
  }
  function hexToRgba(value) {
    const trimmed = value.trim();
    const rgbaMatch = trimmed.match(
      /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/
    );
    if (rgbaMatch) {
      return {
        r: parseInt(rgbaMatch[1]) / 255,
        g: parseInt(rgbaMatch[2]) / 255,
        b: parseInt(rgbaMatch[3]) / 255,
        a: rgbaMatch[4] ? parseFloat(rgbaMatch[4]) : 1
      };
    }
    const hex = trimmed.replace("#", "");
    return {
      r: parseInt(hex.slice(0, 2), 16) / 255,
      g: parseInt(hex.slice(2, 4), 16) / 255,
      b: parseInt(hex.slice(4, 6), 16) / 255,
      a: hex.length === 8 ? parseInt(hex.slice(6, 8), 16) / 255 : 1
    };
  }
  function readAllFigmaVariables() {
    var _a;
    const collections = figma.variables.getLocalVariableCollections();
    const result = {};
    for (const collection of collections) {
      const modeId = (_a = collection.modes[0]) == null ? void 0 : _a.modeId;
      if (!modeId) continue;
      for (const id of collection.variableIds) {
        const v = figma.variables.getVariableById(id);
        if (!v) continue;
        const type = figmaTypeToLayoutType(v.resolvedType);
        if (!result[type]) result[type] = [];
        result[type].push({
          name: stripGroupPrefix(v.name),
          value: resolveValue(v, modeId),
          cssVariable: null
        });
      }
    }
    return result;
  }
  function figmaTypeToLayoutType(type) {
    switch (type) {
      case "COLOR":
        return "color";
      case "FLOAT":
        return "spacing";
      case "STRING":
        return "typography";
      default:
        return "spacing";
    }
  }
  var COLLECTION_NAME, MODE_NAME;
  var init_figma_variables = __esm({
    "src/lib/figma-variables.ts"() {
      "use strict";
      COLLECTION_NAME = "Layout";
      MODE_NAME = "Default";
    }
  });

  // src/lib/assemble-variants.ts
  function assembleComponentSet(options) {
    return __async(this, null, function* () {
      const { componentName, wireHover } = options;
      const prefix = `${componentName}/State=`;
      const frames = figma.currentPage.children.filter(
        (n) => n.type === "FRAME" && n.name.startsWith(prefix)
      );
      if (frames.length === 0) {
        throw new Error(
          `No variant frames found for "${componentName}". Push variants from Layout CLI first.`
        );
      }
      const variantNames = frames.map((f) => f.name.replace(prefix, ""));
      const components = [];
      for (const frame of frames) {
        const component = figma.createComponent();
        component.name = frame.name;
        component.resize(frame.width, frame.height);
        if (frame.layoutMode !== "NONE") {
          component.layoutMode = frame.layoutMode;
          component.primaryAxisSizingMode = frame.primaryAxisSizingMode;
          component.counterAxisSizingMode = frame.counterAxisSizingMode;
          component.itemSpacing = frame.itemSpacing;
          component.paddingTop = frame.paddingTop;
          component.paddingRight = frame.paddingRight;
          component.paddingBottom = frame.paddingBottom;
          component.paddingLeft = frame.paddingLeft;
        }
        component.fills = JSON.parse(JSON.stringify(frame.fills));
        component.strokes = JSON.parse(JSON.stringify(frame.strokes));
        component.effects = JSON.parse(JSON.stringify(frame.effects));
        if (typeof frame.cornerRadius === "number") {
          component.cornerRadius = frame.cornerRadius;
        }
        for (const child of [...frame.children]) {
          component.appendChild(child);
        }
        component.x = frame.x;
        component.y = frame.y;
        components.push(component);
        frame.remove();
      }
      const componentSet = figma.combineAsVariants(components, figma.currentPage);
      componentSet.name = componentName;
      let hoverWired = false;
      if (wireHover !== false) {
        const defaultComp = components.find(
          (c) => c.name.includes("State=Default")
        );
        const hoverComp = components.find((c) => c.name.includes("State=Hover"));
        if (defaultComp && hoverComp) {
          yield defaultComp.setReactionsAsync([
            {
              trigger: { type: "MOUSE_ENTER", delay: 0, deprecatedVersion: false },
              actions: [
                {
                  type: "NODE",
                  destinationId: hoverComp.id,
                  navigation: "SWAP",
                  transition: null
                }
              ]
            }
          ]);
          yield hoverComp.setReactionsAsync([
            {
              trigger: { type: "MOUSE_LEAVE", delay: 0, deprecatedVersion: false },
              actions: [
                {
                  type: "NODE",
                  destinationId: defaultComp.id,
                  navigation: "SWAP",
                  transition: null
                }
              ]
            }
          ]);
          hoverWired = true;
        }
      }
      return {
        componentSetId: componentSet.id,
        componentSetName: componentSet.name,
        variantCount: components.length,
        variantNames,
        hoverWired
      };
    });
  }
  var init_assemble_variants = __esm({
    "src/lib/assemble-variants.ts"() {
      "use strict";
    }
  });

  // src/code.ts
  var require_code = __commonJS({
    "src/code.ts"(exports) {
      init_tokens();
      init_components();
      init_screenshots();
      init_auth();
      init_figma_variables();
      init_assemble_variants();
      figma.showUI(__html__, {
        width: 420,
        height: 640,
        themeColors: true,
        title: "Layout \u2014 AI Design System Kit"
      });
      Promise.all([getApiKey(), getBaseUrl()]).then(([apiKey, baseUrl]) => {
        figma.ui.postMessage({ type: "settings-loaded", payload: { apiKey, baseUrl } });
      });
      figma.ui.onmessage = (msg) => __async(exports, null, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
        try {
          switch (msg.type) {
            case "extract-tokens":
              yield handleExtractTokens();
              break;
            case "extract-components":
              yield handleExtractComponents();
              break;
            case "inspect-selection":
              yield handleInspectSelection();
              break;
            case "capture-selection":
              yield handleCaptureSelection();
              break;
            case "get-file-info":
              handleGetFileInfo();
              break;
            case "get-selection":
              handleGetSelection();
              break;
            case "verify-api-key":
              yield handleVerifyApiKey(
                (_a = msg.payload) == null ? void 0 : _a.apiKey,
                (_b = msg.payload) == null ? void 0 : _b.baseUrl
              );
              break;
            case "read-figma-variables":
              figma.ui.postMessage({
                type: "figma-variables-result",
                payload: { variables: readLayoutVariables() }
              });
              break;
            case "write-figma-variables": {
              const tokensByCategory = (_d = (_c = msg.payload) == null ? void 0 : _c.tokensByCategory) != null ? _d : {};
              const toDelete = (_f = (_e = msg.payload) == null ? void 0 : _e.toDelete) != null ? _f : [];
              if (toDelete.length > 0) deleteLayoutVariables(toDelete);
              const result = writeLayoutVariables(tokensByCategory);
              figma.ui.postMessage({ type: "variables-written", payload: result });
              break;
            }
            case "read-all-figma-variables":
              figma.ui.postMessage({
                type: "all-figma-variables-result",
                payload: { variables: readAllFigmaVariables() }
              });
              break;
            case "save-settings":
              if ((_g = msg.payload) == null ? void 0 : _g.apiKey) yield saveApiKey(msg.payload.apiKey);
              if ((_h = msg.payload) == null ? void 0 : _h.baseUrl) yield saveBaseUrl(msg.payload.baseUrl);
              break;
            case "clear-api-key":
              yield clearApiKey();
              break;
            case "resize":
              if (((_i = msg.payload) == null ? void 0 : _i.width) && ((_j = msg.payload) == null ? void 0 : _j.height)) {
                figma.ui.resize(
                  msg.payload.width,
                  msg.payload.height
                );
              }
              break;
            case "scan-variant-frames": {
              const groups = scanVariantFrames();
              figma.ui.postMessage({
                type: "variant-frames-scanned",
                payload: { groups }
              });
              break;
            }
            case "assemble-component-set": {
              const componentName = (_l = (_k = msg.payload) == null ? void 0 : _k.componentName) != null ? _l : "";
              const wireHover = (_n = (_m = msg.payload) == null ? void 0 : _m.wireHover) != null ? _n : true;
              if (!componentName) {
                figma.ui.postMessage({
                  type: "assemble-result",
                  payload: { error: "Component name is required" }
                });
                break;
              }
              const result = yield assembleComponentSet({ componentName, wireHover });
              figma.ui.postMessage({
                type: "assemble-result",
                payload: result
              });
              break;
            }
            default:
              console.warn(`[layout-plugin] Unknown message type: ${msg.type}`);
          }
        } catch (err) {
          const message = err instanceof Error ? err.message : "Unknown error";
          figma.ui.postMessage({ type: "error", payload: { message } });
        }
      });
      function scanVariantFrames() {
        const groups = /* @__PURE__ */ new Map();
        for (const node of figma.currentPage.children) {
          if (node.type !== "FRAME") continue;
          const match = node.name.match(/^(.+)\/State=(.+)$/);
          if (!match) continue;
          const [, componentName, variantName] = match;
          if (!groups.has(componentName)) groups.set(componentName, []);
          groups.get(componentName).push(variantName);
        }
        return Array.from(groups.entries()).map(([componentName, variantNames]) => ({
          componentName,
          variantNames,
          frameCount: variantNames.length
        }));
      }
      function handleExtractTokens() {
        return __async(this, null, function* () {
          figma.ui.postMessage({
            type: "extraction-status",
            payload: { step: "tokens", status: "running" }
          });
          const tokens = yield extractTokensFromPage();
          figma.ui.postMessage({
            type: "extraction-status",
            payload: { step: "tokens", status: "complete" }
          });
          figma.ui.postMessage({
            type: "tokens-extracted",
            payload: { tokens }
          });
        });
      }
      function handleExtractComponents() {
        return __async(this, null, function* () {
          figma.ui.postMessage({
            type: "extraction-status",
            payload: { step: "components", status: "running" }
          });
          const components = yield extractComponents();
          figma.ui.postMessage({
            type: "extraction-status",
            payload: { step: "components", status: "complete" }
          });
          figma.ui.postMessage({
            type: "components-extracted",
            payload: { components }
          });
        });
      }
      function handleInspectSelection() {
        return __async(this, null, function* () {
          const selection = figma.currentPage.selection;
          if (selection.length === 0) {
            figma.ui.postMessage({
              type: "inspection-result",
              payload: { error: "No element selected" }
            });
            return;
          }
          const node = selection[0];
          const inspection = inspectNode(node);
          figma.ui.postMessage({
            type: "inspection-result",
            payload: { inspection }
          });
        });
      }
      function handleCaptureSelection() {
        return __async(this, null, function* () {
          const selection = figma.currentPage.selection;
          if (selection.length === 0) {
            figma.ui.postMessage({
              type: "capture-result",
              payload: { error: "No element selected" }
            });
            return;
          }
          const node = selection[0];
          const screenshot = yield captureScreenshot(node);
          const inspection = inspectNode(node);
          figma.ui.postMessage({
            type: "capture-result",
            payload: { screenshot, inspection }
          });
        });
      }
      function handleGetFileInfo() {
        const file = figma.root;
        figma.ui.postMessage({
          type: "file-info",
          payload: {
            name: file.name,
            pageCount: file.children.length,
            currentPage: figma.currentPage.name
          }
        });
      }
      function handleVerifyApiKey(apiKey, baseUrl) {
        return __async(this, null, function* () {
          var _a;
          const url = `${baseUrl.replace(/\/$/, "")}/api/auth/verify`;
          try {
            const res = yield fetch(url, {
              headers: { Authorization: `Bearer ${apiKey}` }
            });
            if (res.ok) {
              const data = yield res.json();
              figma.ui.postMessage({
                type: "verify-result",
                payload: { valid: true, orgName: (_a = data.org) == null ? void 0 : _a.name }
              });
            } else {
              figma.ui.postMessage({ type: "verify-result", payload: { valid: false } });
            }
          } catch (e) {
            figma.ui.postMessage({ type: "verify-result", payload: { valid: false } });
          }
        });
      }
      function handleGetSelection() {
        const selection = figma.currentPage.selection;
        figma.ui.postMessage({
          type: "selection-info",
          payload: {
            count: selection.length,
            nodes: selection.slice(0, 10).map((n) => ({
              id: n.id,
              name: n.name,
              type: n.type,
              width: "width" in n ? n.width : void 0,
              height: "height" in n ? n.height : void 0
            }))
          }
        });
      }
      function inspectNode(node) {
        const inspection = {
          name: node.name,
          type: node.type
        };
        if ("width" in node) inspection.width = node.width;
        if ("height" in node) inspection.height = node.height;
        if ("fills" in node && Array.isArray(node.fills)) {
          inspection.fills = node.fills.filter((f) => f.type === "SOLID").map((f) => ({
            type: "SOLID",
            color: rgbToHex2(f.color),
            opacity: f.opacity
          }));
        }
        if ("strokes" in node && Array.isArray(node.strokes)) {
          inspection.strokes = node.strokes.filter((f) => f.type === "SOLID").map((f) => ({
            type: "SOLID",
            color: rgbToHex2(f.color)
          }));
        }
        if ("cornerRadius" in node && typeof node.cornerRadius === "number") {
          inspection.cornerRadius = node.cornerRadius;
        }
        if (node.type === "TEXT") {
          const textNode = node;
          if (typeof textNode.fontSize === "number") {
            inspection.fontSize = textNode.fontSize;
          }
          const fontName = textNode.fontName;
          if (typeof fontName === "object" && "family" in fontName) {
            inspection.fontFamily = fontName.family;
            inspection.fontWeight = fontWeightFromStyle2(fontName.style);
          }
          const lh = textNode.lineHeight;
          if (typeof lh === "object" && "unit" in lh && lh.unit !== "AUTO") {
            inspection.lineHeight = lh.unit === "PERCENT" ? `${lh.value}%` : `${lh.value}px`;
          }
          const ls = textNode.letterSpacing;
          if (typeof ls === "object" && "unit" in ls) {
            inspection.letterSpacing = ls.unit === "PERCENT" ? `${ls.value}%` : `${ls.value}px`;
          }
        }
        if ("effects" in node && Array.isArray(node.effects)) {
          inspection.effects = node.effects.map((e) => ({
            type: e.type,
            color: "color" in e ? rgbaToString2(e.color) : void 0,
            offset: "offset" in e ? e.offset : void 0,
            radius: "radius" in e ? e.radius : void 0
          }));
        }
        if ("layoutMode" in node) {
          const frame = node;
          if (frame.layoutMode !== "NONE") {
            inspection.layoutMode = frame.layoutMode;
            inspection.gap = frame.itemSpacing;
            inspection.padding = {
              top: frame.paddingTop,
              right: frame.paddingRight,
              bottom: frame.paddingBottom,
              left: frame.paddingLeft
            };
          }
        }
        if ("children" in node) {
          const colors = /* @__PURE__ */ new Set();
          const fontFamilies = /* @__PURE__ */ new Set();
          const fontSizes = /* @__PURE__ */ new Set();
          const cornerRadii = /* @__PURE__ */ new Set();
          const spacings = /* @__PURE__ */ new Set();
          collectChildTokens(node, colors, fontFamilies, fontSizes, cornerRadii, spacings);
          inspection.childTokens = {
            colors: Array.from(colors).sort(),
            fontFamilies: Array.from(fontFamilies).sort(),
            fontSizes: Array.from(fontSizes).sort((a, b) => parseFloat(a) - parseFloat(b)),
            cornerRadii: Array.from(cornerRadii).sort((a, b) => parseFloat(a) - parseFloat(b)),
            spacings: Array.from(spacings).sort((a, b) => parseFloat(a) - parseFloat(b))
          };
        }
        return inspection;
      }
      function collectChildTokens(node, colors, fontFamilies, fontSizes, cornerRadii, spacings) {
        if ("fills" in node && Array.isArray(node.fills)) {
          for (const f of node.fills) {
            if (f.type === "SOLID" && f.visible !== false) {
              colors.add(rgbToHex2(f.color));
            }
          }
        }
        if ("cornerRadius" in node && typeof node.cornerRadius === "number" && node.cornerRadius > 0) {
          cornerRadii.add(`${node.cornerRadius}px`);
        }
        if (node.type === "TEXT") {
          const t = node;
          if (typeof t.fontSize === "number") fontSizes.add(`${t.fontSize}px`);
          if (typeof t.fontName === "object" && "family" in t.fontName) fontFamilies.add(t.fontName.family);
        }
        if ("layoutMode" in node) {
          const f = node;
          if (f.layoutMode !== "NONE") {
            if (f.itemSpacing > 0) spacings.add(`${f.itemSpacing}px`);
            if (f.paddingTop > 0) spacings.add(`${f.paddingTop}px`);
            if (f.paddingRight > 0) spacings.add(`${f.paddingRight}px`);
            if (f.paddingBottom > 0) spacings.add(`${f.paddingBottom}px`);
            if (f.paddingLeft > 0) spacings.add(`${f.paddingLeft}px`);
          }
        }
        if ("children" in node) {
          for (const child of node.children) {
            collectChildTokens(child, colors, fontFamilies, fontSizes, cornerRadii, spacings);
          }
        }
      }
      function rgbToHex2(color) {
        const r = Math.round(color.r * 255);
        const g = Math.round(color.g * 255);
        const b = Math.round(color.b * 255);
        return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
      }
      function rgbaToString2(color) {
        const r = Math.round(color.r * 255);
        const g = Math.round(color.g * 255);
        const b = Math.round(color.b * 255);
        return `rgba(${r}, ${g}, ${b}, ${color.a.toFixed(2)})`;
      }
      function fontWeightFromStyle2(style) {
        var _a;
        const map = {
          Thin: 100,
          Hairline: 100,
          ExtraLight: 200,
          UltraLight: 200,
          Light: 300,
          Regular: 400,
          Normal: 400,
          Medium: 500,
          SemiBold: 600,
          DemiBold: 600,
          Bold: 700,
          ExtraBold: 800,
          UltraBold: 800,
          Black: 900,
          Heavy: 900
        };
        return (_a = map[style.replace(/\s/g, "")]) != null ? _a : 400;
      }
      figma.on("selectionchange", () => {
        handleGetSelection();
      });
    }
  });
  require_code();
})();
