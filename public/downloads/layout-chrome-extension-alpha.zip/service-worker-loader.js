import './assets/service-worker.ts-CGVaVlQ2.js';
